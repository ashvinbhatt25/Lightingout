## Create Salesforce IDE in 30 minutes

Sample Source code to create simple IDE for Salesforce which uses Tooling API.

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

Demo - https://toolingapi.herokuapp.com/